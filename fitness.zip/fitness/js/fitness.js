//Javascript

//document.getElementById('jq').innerHTML = "NO";

//jQuery('.active').clone().appendTo( "#active-page" );
jQuery('#active-page').html( jQuery('li.active>a').html() );