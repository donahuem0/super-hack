    <footer class="footer">
      <div class="container">
        
        <span class="site-info">
	        <a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
	          &copy; <?php echo date("Y"); ?> <?php bloginfo( 'name' ); ?>
	         </a>
	      </span>
	      
        <div class="pull-right">
          <a href="https://www.facebook.com/fitclubfoundation/?hc_ref=SEARCH" target="_blank">
            <i class="fa fa-facebook-square fa-3x" aria-hidden="true"></i>
          </a>
          <a href="https://twitter.com/search?q=FITCLUBworc&src=typd" target="_blank">
            <i class="fa fa-twitter-square fa-3x" aria-hidden="true"></i>
          </a>
          <a href="https://www.instagram.com/fitclubfoundation/" target="_blank">
            <i class="fa fa-instagram fa-3x" aria-hidden="true"></i>
          </a>
        </div><!-- /.pull-right -->
      </div><!-- /.container -->
    </footer>
    
    <?php wp_footer(); ?>
  </body> 
</html> 