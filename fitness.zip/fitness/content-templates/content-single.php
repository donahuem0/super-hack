<?php
/**
 * Page Content Template
 * Used for generic pages
 */
?>
<div class="container" >
  <h3>
    
      <?php the_title(); ?>
    
  </h3>

  <?php the_content(); ?>

</div>